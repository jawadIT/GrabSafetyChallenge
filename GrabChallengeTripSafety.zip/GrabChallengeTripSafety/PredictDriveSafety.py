import pandas as pd
import os,math
from os import path
import win32com.client as win32
import pythoncom
from pyspark.sql import SparkSession, SQLContext
from pyspark.sql.functions import col, expr, when, substring, udf
from pyspark.sql.types import *
from pyspark.ml import Pipeline, PipelineModel
from flask import Flask, request, make_response, Response, send_file
import gzip as gz
import zipfile as zf
import shutil as sl
from shutil import make_archive
from flasgger import Swagger
from gevent.pywsgi import WSGIServer
import smtplib
from email.mime.image import MIMEImage
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email.mime.text import MIMEText
from email import encoders


def create_spark_session(app_name="PredictDriveSafety"):
    spark_session = SparkSession.builder.appName(app_name).master("local[*]").getOrCreate()
    spark_session.sparkContext.setLogLevel("WARN")
    return  spark_session


def predict(model,filenm,testData):
    print('prediction in progress')
    preds = model.transform(testData)
    #path = "C:/Users/z001133/cqanalytics/safety/liveAPI/data/result" + "/" + filenm + ".csv"
    #tpath = "C:/Users/z001133/cqanalytics/safety/liveAPI/data/result" + "/" + filenm + ".csv.gz"
    path1 = "./" + filenm + ".csv"
    tpath = "./" + filenm + ".csv.gz"
    if os.path.exists(path1):
        os.remove(path1)
    else:
        print("Can not delete the file as it doesn't exists")
    if os.path.exists(tpath):
        os.remove(tpath)
    else:
        print("Can not delete the file as it doesn't exists")

    preds.toPandas() \
        .to_csv(path1)
    store_file(path1,tpath)
    store_file2(filenm)
    #email1(filenm)
    return

def store_file(path1,tpath):
    with open(path1,"rb") as f_in,  gz.open(tpath,"wb") as f_out:
        sl.copyfileobj(f_in, f_out)
    return

def store_file2(filenm):
    cwd = os.getcwd()
    print(cwd)
    sl.make_archive(filenm,"zip",cwd + "./")
    return

def email1(filenm):

    cwd = os.getcwd()
    print(cwd)
    themsg  = MIMEMultipart()
    themsg ['From'] = "jawad.shaik@rntbci.com"
    themsg ['To'] = "jawad.shaik@rntbci.com"
    themsg ['Subject'] = "ML result for safety alerts"
    msg = MIMEBase('application', 'zip')
    zf1 = zf.ZipFile("./" + filenm + ".zip",'w')
    msg.set_payload(zf1.read())
    msg.attach(MIMEText("attached is the result from ML for safety alert classification",'plain'))
    part = MIMEBase('application', "octet-stream")
    part.set_payload(zf1.read())
    encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="file.zip"')
    msg.attach(part)
    smtp = smtplib.SMTP("localhost")
    smtp.sendmail("jawad.shaik@rntbci.com", "jawad.shaik@rntbci.com", msg.as_string())
    smtp.close()
    return

def get_accelaration_magnitude(a,b,c):
    p = (a*a + b*b + c*c)
    return math.sqrt(p)
get_accelaration_magnitude_udf = udf(get_accelaration_magnitude)

def check_first_row(a,b):
    if b != 0:
        return a-b
    else:
        return 0
check_first_row_udf = udf(check_first_row)

def column_manipulations(dfin,spark):

    dfin = dfin.withColumn("degreesX",dfin["gyro_x"]*57.2958) \
        .withColumn("degreesY",dfin["gyro_y"]*57.2958) \
        .withColumn("degreesZ",dfin["gyro_z"]*57.2958) \
        .withColumn("acc_magn",get_accelaration_magnitude_udf(dfin["acceleration_x"],dfin["acceleration_y"],dfin["acceleration_z"])) \
        .withColumn("speedT",dfin["Speed"])

    dfin = dfin.select("bookingID","second","Accuracy","Bearing","degreesZ","acc_magn","Speed","speedT")

    dfin = dfin.groupby(['bookingID','Accuracy','Bearing']) \
        .agg({
        "degreesZ": "mean",
        "acc_magn": "mean",
        "second": "max",
        "Speed": "mean",
        "speedT": "sum"
    }) \
        .withColumnRenamed("bookingID","bkid") \
        .withColumnRenamed("Bearing","brng") \
        .withColumnRenamed("Accuracy","acrc") \
        .withColumnRenamed("avg(degreesZ)","degreesZ") \
        .withColumnRenamed("avg(acc_magn)","acc_magn") \
        .withColumnRenamed("max(second)","sub_total_time") \
        .withColumnRenamed("avg(Speed)","speed") \
        .withColumnRenamed("sum(speedT)","sub_total_distance")

    dfin = dfin.withColumn("speedhr",3.6*dfin['speed']) \
        .withColumn("timehr",dfin['sub_total_time']/3600) \
        .withColumn("dist",dfin['sub_total_distance']/1000)

    dfin = dfin.withColumn("timehrT",dfin['timehr']) \
        .withColumn("distT",dfin['dist'])

    dfin.createOrReplaceTempView('df_01')

    df_02 = spark.sql("""select *,lag(brng,1,0) over (partition by bkid order by timehr) as prev_brng,
     lag(acrc,1,0) over (partition by bkid order by timehr) as prev_acrc,
     lag(acc_magn,1,0) over (partition by bkid order by timehr) as prev_acc_magn,
     lag(degreesZ,1,0) over (partition by bkid order by timehr) as prev_degreesZ,
     lag(dist,1,0) over (partition by bkid order by timehr) as prev_dist,
     lag(speedhr,1,0) over (partition by bkid order by timehr) as prev_speed from df_01""")

    df_02 = df_02.withColumn('delta_brng',check_first_row_udf(df_02['brng'],df_02['prev_brng'])) \
        .withColumn('delta_acrc',check_first_row_udf(df_02['acrc'],df_02['prev_acrc'])) \
        .withColumn('delta_acc_magn',check_first_row_udf(df_02['acc_magn'],df_02['prev_acc_magn'])) \
        .withColumn('delta_degreesZ',check_first_row_udf(df_02['degreesZ'],df_02['prev_degreesZ'])) \
        .withColumn('delta_dist',check_first_row_udf(df_02['dist'],df_02['prev_dist'])) \
        .withColumn('delta_speed',check_first_row_udf(df_02['speedhr'],df_02['prev_speed']))

    df_03 = df_02.groupBy('bkid') \
        .agg({
        "brng": "std",
        "bkid": "count",
        "acrc": "std",
        "degreesZ": "std",
        "speedhr": "std",
        "acc_magn": "std",
        "timehr": "max",
        "timehrT": "mean",
        "dist": "mean",
        "distT": "sum",
        "delta_brng": "std",
        "delta_acrc": "std",
        "delta_acc_magn": "std",
        "delta_degreesZ": "std",
        "delta_dist": "std",
        "delta_speed": "std"
    }) \
        .withColumnRenamed("bkid","bookID") \
        .withColumnRenamed("stddev(brng)","bearing") \
        .withColumnRenamed("count(bkid)","no_of_turns") \
        .withColumnRenamed("stddev(acrc)","accuracy") \
        .withColumnRenamed("stddev(degreesZ)","degreesZ") \
        .withColumnRenamed("stddev(acc_magn)","acc_magn") \
        .withColumnRenamed("avg(timehrT)","time_per_turn") \
        .withColumnRenamed("max(timehr)","total_time") \
        .withColumnRenamed("stddev(speedhr)","speed") \
        .withColumnRenamed("avg(dist)","distance_per_turn") \
        .withColumnRenamed("sum(distT)","total_ditance") \
        .withColumnRenamed("stddev(delta_brng)","change_in_bearing") \
        .withColumnRenamed("stddev(delta_acrc)","change_in_accuracy") \
        .withColumnRenamed("stddev(delta_acc_magn)","change_in_accelaration") \
        .withColumnRenamed("stddev(delta_degreesZ)","change_in_gyro") \
        .withColumnRenamed("stddev(delta_dist)","change_in_dist") \
        .withColumnRenamed("stddev(delta_speed)","change_in_speed")


    df_03.withColumn("class",dummy_return_0_udf())


    return df_03

column_manipulations_udf = udf(column_manipulations)

def dummy_return_0():
    return 0
dummy_return_0_udf = udf(dummy_return_0)

def main():

    print("entry in to the job")
    #create spark session
    spark = create_spark_session()
    #create sql context
    sq = SQLContext(spark)
    app = Flask(__name__)
    swagger = Swagger(app)
    @app.route('/',methods=['GET','POST'])
    def predict_drive_safety():
        """Example file endpoint to predict drive safety alerts
        ---
        parameters:
            - name: input_file
              in: formData
              type: file
              required: true
        """
        print("entry")
        dfres = sq.createDataFrame(pd.read_csv(request.files.get("input_file"),encoding='cp1252'))
        dfclean_res = column_manipulations(dfres,spark)
        #PicklePath = "C:/Users/z001133/cqanalytics/safety/liveAPI/models/cqsafety_logV1.0.pkl"
        PicklePath = "./models/log/log_model.pkl"
        model1 = PipelineModel.load(PicklePath)
        print("model loaded")
        #FilePath1 = "C:/Users/z001133/Desktop/work files/customer quality/SAFETY/data/jan1st.csv"
        #dfres = sq.createDataFrame(pd.read_csv(FilePath1,header=0,engine='python'),schema=file_schema())
        filenm1 = "grab_trip_safety_alert"
        predict(model1,filenm1,dfclean_res)
        print("before return")
        return

    app.run(debug=False,host='0.0.0.0',port=5000)
    #app.run(port=5000)
    #http_server = WSGIServer(('127.0.0.1', 8080), app)
    #http_server.serve_forever()


if __name__ == '__main__':
    main()




